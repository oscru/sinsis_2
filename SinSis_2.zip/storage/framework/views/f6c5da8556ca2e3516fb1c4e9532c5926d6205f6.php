        <link rel="stylesheet" href=<?php echo e(asset('css/animate.css')); ?> />
        <!-- bootstrap -->
        <link rel="stylesheet" href=<?php echo e(asset('css/bootstrap.min.css')); ?> />
        <!-- et line icon --> 
        <link rel="stylesheet" href=<?php echo e(asset('css/et-line-icons.css')); ?> />
        <!-- font-awesome icon -->
        <link rel="stylesheet" href=<?php echo e(asset('css/font-awesome.min.css')); ?> />
        <!-- themify icon -->
        <link rel="stylesheet" href=<?php echo e(asset('css/themify-icons.css')); ?>>
        <!-- swiper carousel -->
        <link rel="stylesheet" href=<?php echo e(asset('css/swiper.min.css')); ?>>
        <!-- justified gallery  -->
        <link rel="stylesheet" href=<?php echo e(asset('css/justified-gallery.min.css')); ?>>
        <!-- magnific popup -->
        <link rel="stylesheet" href=<?php echo e(asset('css/magnific-popup.css')); ?> />
        <!-- revolution slider -->
        
        <!-- bootsnav -->
        <link rel="stylesheet" href=<?php echo e(asset('css/bootsnav.css')); ?>>
        <!-- style -->
        <link rel="stylesheet" href=<?php echo e(asset('css/style.css')); ?> />
        <!-- responsive css -->
        <link rel="stylesheet" href=<?php echo e(asset('css/responsive.css')); ?> />
        <!--[if IE]>
            <script src="js/html5shiv.js"></script>
        <![endif]-->
        <link rel="stylesheet" href="<?php echo e(asset('css/styles/main.css')); ?>"><?php /**PATH /mnt/d/projects/SinSis/resources/views/maincss.blade.php ENDPATH**/ ?>