<?php $__env->startSection('title', 'Crear Proyecto | Panel de Administación SinSis'); ?>
<?php $__env->startSection('body'); ?>
<section class="wow fadeIn main-admin-container">
    <header class="main-admin-header position-fixed">
       <span>Nuevo Diagnostico</span>
    </header>
    <div class="container projects-container">        
        <div class="row">
            <div class="col-12 wow fadeIn">
                <form action=<?php echo e(route( 'store-diagnostics' )); ?> method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    
                    <label for="">Descripcion</label>
                    <textarea name="texto" id="" cols="30" rows="10"></textarea>
                    <label for="">PDF</label>
                    <input type="file" name="file" id="" accept=".pdf,.PDF">
                    <input type="hidden" name="project_id" value=<?php echo e($project); ?>>
                    <input type="submit" name="button_1" value="Enviar">
                </form>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\SinSis\resources\views/admin/diagnostics/create.blade.php ENDPATH**/ ?>