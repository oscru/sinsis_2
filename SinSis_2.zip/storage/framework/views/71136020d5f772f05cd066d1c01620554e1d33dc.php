<?php $__env->startSection('title', 'Crear Proyecto | Panel de Administación SinSis'); ?>
<?php $__env->startSection('body'); ?>
<section class="wow fadeIn main-admin-container">
    <header class="main-admin-header position-fixed">
       <span>Nueva Entrevista</span>
    </header>
    <div class="container projects-container">        
        <div class="row">
            <div class="col-12 wow fadeIn">
                <form action="<?php echo e(route('create-enterview')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="project" value=<?php echo e($project_id); ?>>
                <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($question-> id == 6): ?>
                <div id="<?php echo e($conta++); ?>">
                    <label value="<?php echo e($question->id); ?> "><?php echo e($question->question); ?></label>
                    <div class="box">
                        <input type="checkbox" name="<?php echo e($question->id); ?>" id="si"><p class="si">Si</p>
                    </div>
                </div>
                <?php else: ?>
                <div class="<?php echo e($conta==7 || $conta==8 || $conta==9 ? 'd-none  pregunta-sec':''); ?>" id="<?php echo e($conta++); ?>">
                    <label value="<?php echo e($question->id); ?> "><?php echo e($question->question); ?></label>
                    <input type="text" name="<?php echo e($question->id); ?>" id="">
                </div>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <input type="submit" name="button_1" value="Enviar">
                </form>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\SinSis\resources\views/admin/enterview/create.blade.php ENDPATH**/ ?>