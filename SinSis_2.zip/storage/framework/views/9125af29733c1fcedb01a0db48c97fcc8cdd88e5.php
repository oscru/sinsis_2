<?php $__env->startSection('title', 'Crear Proyecto | Panel de Administación SinSis'); ?>
<?php $__env->startSection('body'); ?>
<section class="wow fadeIn main-admin-container">
    <header class="main-admin-header position-fixed">
       <span>Nuevo Usuario</span>
    </header>
    <div class="container projects-container">        
        <div class="row">
            <div class="col-12 wow fadeIn">
                <form action="" method="post">
                    <label for="">Nombre</label>
                    <input type="text" name="" id="">
                    <label for="">Correo electronico</label>
                    <input type="text" name="" id="">
                    <label for="">Contraseña</label>
                    <input type="password" name="" id="">
                    <label for="">Nivel de acceso</label>
                    <input type="text" name="" id="">
                    <label for="">Cargo</label>
                    <input type="text" name="" id="">
                    <!--<label for="">Descripcion:</label>
                    <textarea name="" id="" cols="30" rows="10"></textarea>-->
                    <!--<label for="">Empresa</label>-->
                </form>
                <input type="submit" name="button_1" value="Enviar">
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\SinSis_2\resources\views/admin/users/create.blade.php ENDPATH**/ ?>