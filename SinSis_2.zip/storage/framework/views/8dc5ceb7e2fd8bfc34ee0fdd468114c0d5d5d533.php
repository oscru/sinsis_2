<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>">
        
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('images/favicon.ico')); ?>">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
        <?php echo $__env->yieldContent('meta'); ?>
        <?php echo $__env->make('maincss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('css'); ?>
        <?php $route = Route::currentRouteName() ?>
</head>
    <body data-lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">        
        <?php echo $__env->make('admin.components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="sidebar-wrapper bg-light-gray md-padding-50px-top">
        <?php echo $__env->yieldContent('body'); ?>
        </div>        
        <?php echo $__env->make('mainjs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>        
        <link href="https://fonts.googleapis.com/css?family=Barlow:300,400,500,600,700,800&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700&display=swap" rel="stylesheet">
        <?php echo $__env->yieldContent('own-js'); ?>
        <?php echo $__env->yieldPushContent('scripts'); ?>      
    </body>
</html>
<?php /**PATH D:\Projects\SinSis_2\resources\views/admin/layout.blade.php ENDPATH**/ ?>