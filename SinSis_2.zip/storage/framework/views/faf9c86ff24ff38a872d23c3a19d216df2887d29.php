<?php $__env->startSection('title', 'Crear Proyecto | Panel de Administación SinSis'); ?>
<?php $__env->startSection('body'); ?>
<section class="wow fadeIn main-admin-container">
    <header class="main-admin-header position-fixed">
       <span>Nueva Empresa</span>
    </header>
    <div class="container projects-container">        
        <div class="row">
            <div class="col-12 wow fadeIn">
                <form action="<?php echo e(route('create-enterprise')); ?>" method="post" >
                <?php echo csrf_field(); ?>
                    <label for="">Nombre de la empresa</label>
                    <input type="text" name="name" id="">
                    <label for="">Nombre corporativo</label>
                    <input type="text" name="business_name" id="">
                    <label for="">Dirección</label>
                    <input type="text" name="location" id="">
                    <label for="">encargado</label>
                   
                    <input type="text" name="manager" id="">
                    <input type="submit" name="button_1" value="Enviar">
                </form>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\SinSis\resources\views/admin/enterprises/create.blade.php ENDPATH**/ ?>