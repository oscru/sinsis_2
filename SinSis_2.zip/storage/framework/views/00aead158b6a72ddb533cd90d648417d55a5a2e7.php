
<?php $__env->startSection('title', 'Crear Proyecto | Panel de Administación SinSis'); ?>
<?php $__env->startSection('body'); ?>
<!-- start list style 05 section -->

<section class="enterview wow fadeIn bg-extra-dark-gray">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-12 col-lg-7 text-center margin-100px-bottom sm-margin-40px-bottom">
                        <div class="position-relative overflow-hidden w-100">
                            <span class="titles text-small text-outside-line-full alt-font font-weight-600 text-uppercase">Entrevistas</span>
                            <header class="main-admin-header position-fixed">
                                <a href=<?php echo e(route('create-enterview')); ?> class="">+ Crear Nueva Entrevista</a>
                            </header>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="col-12 col-lg-6 col-md-10">
                    <?php if(@$enterview != null): ?>
                        <ul class="list-style-9 margin-twelve-left">
                            <?php $__currentLoopData = $enterview; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enterview): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="text-uppercase"><span class="titles d-block text-extra-small text-white-2"><?php echo e($enterview++); ?></span><a class="ver" href="index.html">Ver más</a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                        </ul>
                        <?php else: ?>
                        <h2>TU PUTA MADRE</h2>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </section>
        <!-- end list style 05 section -->
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\SinSis\resources\views/admin/enterview/index.blade.php ENDPATH**/ ?>