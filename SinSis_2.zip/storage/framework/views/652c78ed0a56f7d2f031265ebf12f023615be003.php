<!-- start navigation -->
<nav class="navbar no-margin-bottom bootsnav alt-font bg-white sidebar-nav sidebar-nav-style-1 navbar-expand-lg">
  <!-- start logo -->
  <div class="col-12 sidenav-header">
      <div class="logo-holder">
          <a href=<?php echo e(route('admin')); ?> class="display-inline-block logo big-logo"><img alt="SinSis" src=<?php echo e(asset('images/logos/logo-sinsis.png')); ?> data-rjs=<?php echo e(asset('images/logos/logo-sinsis.png')); ?> /></a>
          <a href=<?php echo e(route('home')); ?> class="display-inline-block logo display-none"><img alt="SinSis" src=<?php echo e(asset('images/logos/logo-sinsis-mini.png')); ?> data-rjs=<?php echo e(asset('images/logos/logo-sinsis-mini.png')); ?> /></a>
      </div>
      <button class="navbar-toggler mobile-toggle" type="button" id="mobileToggleSidenav">
        <span></span>
        <span></span>
        <span></span>
    </button>
      
      <!-- end logo -->      
  </div>
  <div class="col-12 px-0">
      <div id="navbar-menu" class="collapse navbar-collapse no-padding">
          <ul class="nav navbar-nav navbar-left-sidebar font-weight-500">
            <li class="dropdown">
                <a href=<?php echo e(route('logout')); ?>><?php echo e(Auth::user()->name); ?> <span class="text-extra-small">(logout)</span></a>
            </li>
              <li class="dropdown">
                  <a href=<?php echo e(route('projects')); ?> title="Proyectos" data-toggle="dropdown">Proyectos<i class="fas fa-angle-right pull-right"></i></a>
                  <ul class="dropdown-menu second-level">
                      <li class="dropdown">
                          <a href=<?php echo e(route('create-project')); ?> title="Projectos" data-toggle="dropdown">Nuevo</i></a>
                      </li>
                      <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="dropdown">
                            <a href="<?php echo e(route('set-project-view',$project->slug)); ?>" title="Projectos" data-toggle="dropdown"><?php echo e($project->name); ?></i></a>                          
                        </li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                  </ul>
              </li>

            <li class="dropdown">
                    <a href=<?php echo e(route('user')); ?> title="Proyectos" data-toggle="dropdown">Usuarios<i class="fas fa-angle-right pull-right"></i></a>
                <ul class="dropdown-menu second-level">
                    <li class="dropdown">
                          <a href=<?php echo e(route('create-user')); ?> title="Projectos" data-toggle="dropdown">Nuevo</i></a>
                    </li>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="dropdown">
                        <a href="#" title=<?php echo e($user->name); ?> data-toggle="dropdown"><?php echo e($user->name); ?></a>
                    </li>    
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                </ul>
            </li>
              <li class="dropdown">
                  <a data-toggle="dropdown" href="#" title="Empresas">Empresas <i class="fas fa-angle-right"></i></a>
                  <ul class="dropdown-menu second-level">
                    <li class="dropdown">
                        <a href="#" title="About" data-toggle="dropdown">Nuevo</a>
                    </li>    
                      <?php $__currentLoopData = $side_enterprises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $side_enterprise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="dropdown">
                            <a href="#" title=<?php echo e($side_enterprise->name); ?> data-toggle="dropdown"><?php echo e($side_enterprise->name); ?></a>
                        </li>    
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                  
                  </ul>
              </li>
              
                  <div class="side-left-menu-close close-side"></div>
              </li>
          </ul>
      </div>
  </div>
  <div class="col-12 position-absolute top-auto bottom-0 left-0 width-100 padding-20px-bottom sm-padding-15px-bottom">
      <div class="footer-holder">                   
          <div class="text-medium-gray text-extra-small border-top border-color-extra-light-gray padding-twelve-top sm-padding-15px-top">&COPY; 2020 SinSis. Todos los Derechos Reservados</div>
      </div>
  </div>
</nav>
<!-- end navigation --> <?php /**PATH D:\Projects\SinSis\resources\views/admin/components/sidebar.blade.php ENDPATH**/ ?>