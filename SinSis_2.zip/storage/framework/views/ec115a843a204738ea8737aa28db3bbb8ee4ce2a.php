        
        <!-- start scroll to top -->
        <a class="scroll-top-arrow" href="#"><i class="ti-arrow-up"></i></a>
        <!-- end scroll to top  -->
        <!-- javascript libraries -->
        <script type="text/javascript" src=<?php echo e(asset('js/jquery.js')); ?>></script>
        <script type="text/javascript" src=<?php echo e(asset('js/modernizr.js')); ?>></script>
        <script type="text/javascript" src=<?php echo e(asset('js/bootstrap.bundle.js')); ?>></script>
        <script type="text/javascript" src=<?php echo e(asset('js/jquery.easing.1.3.js')); ?>></script>
        <script type="text/javascript" src=<?php echo e(asset('js/skrollr.min.js')); ?>></script>
        <script type="text/javascript" src=<?php echo e(asset('js/smooth-scroll.js')); ?>></script>
        <script type="text/javascript" src=<?php echo e(asset('js/jquery.appear.js')); ?>></script>
        <!-- menu navigation -->
        <script type="text/javascript" src=<?php echo e(asset('js/bootsnav.js')); ?>></script>
        <script type="text/javascript" src=<?php echo e(asset('js/jquery.nav.js')); ?>></script>
        <!-- animation -->
        <script type="text/javascript" src=<?php echo e(asset('js/wow.min.js')); ?>></script>
        <!-- page scroll -->
        <script type="text/javascript" src=<?php echo e(asset('js/page-scroll.js')); ?>></script>
        <!-- swiper carousel -->
        <script type="text/javascript" src=<?php echo e(asset('js/swiper.min.js')); ?>></script>
        <!-- counter -->
        <script type="text/javascript" src=<?php echo e(asset('js/jquery.count-to.js')); ?>></script>
        <!-- parallax -->
        <script type="text/javascript" src=<?php echo e(asset('js/jquery.stellar.js')); ?>></script>
        <!-- magnific popup -->
        <script type="text/javascript" src=<?php echo e(asset('js/jquery.magnific-popup.min.js')); ?>></script>
        <!-- portfolio with shorting tab -->
        <script type="text/javascript" src=<?php echo e(asset('js/isotope.pkgd.min.js')); ?>></script>
        <!-- images loaded -->
        <script type="text/javascript" src=<?php echo e(asset('js/imagesloaded.pkgd.min.js')); ?>></script>
        <!-- pull menu -->
        <script type="text/javascript" src=<?php echo e(asset('js/classie.js')); ?>></script>
        <script type="text/javascript" src=<?php echo e(asset('js/hamburger-menu.js')); ?>></script>
        <!-- counter  -->
        <script type="text/javascript" src=<?php echo e(asset('js/counter.js')); ?>></script>
        <!-- fit video  -->
        <script type="text/javascript" src=<?php echo e(asset('js/jquery.fitvids.js')); ?>></script>
        <!-- skill bars  -->
        <script type="text/javascript" src=<?php echo e(asset('js/skill.bars.jquery.js')); ?>></script> 
        <!-- justified gallery  -->
        <script type="text/javascript" src=<?php echo e(asset('js/justified-gallery.min.js')); ?>></script>
        <!--pie chart-->
        <script type="text/javascript" src=<?php echo e(asset('js/jquery.easypiechart.min.js')); ?>></script>
        <!-- instagram -->
        <script type="text/javascript" src=<?php echo e(asset('js/instafeed.min.js')); ?>></script>
        <!-- retina -->
        <script type="text/javascript" src=<?php echo e(asset('js/retina.min.js')); ?>></script>
        <!-- revolution -->
        <script type="text/javascript" src=<?php echo e(asset('revolution/js/jquery.themepunch.tools.min.js')); ?>></script>
        <script type="text/javascript" src=<?php echo e(asset('revolution/js/jquery.themepunch.revolution.min.js')); ?>></script>
        <script type="text/javascript" src=<?php echo e(asset('js/main.js')); ?>></script>
        <!--<script type="text/javascript" src=<?php echo e(asset('revolution/js/extensions/revolution.extension.actions.min.js')); ?>></script>
        <script type="text/javascript" src=<?php echo e(asset('revolution/js/extensions/revolution.extension.carousel.min.js')); ?>></script>
        <script type="text/javascript" src=<?php echo e(asset('revolution/js/extensions/revolution.extension.kenburn.min.js')); ?>></script>
        <script type="text/javascript" src=<?php echo e(asset('revolution/js/extensions/revolution.extension.layeranimation.min.js')); ?>></script>
        <script type="text/javascript" src=<?php echo e(asset('revolution/js/extensions/revolution.extension.migration.min.js')); ?>></script>
        <script type="text/javascript" src=<?php echo e(asset('revolution/js/extensions/revolution.extension.navigation.min.js')); ?>></script>
        <script type="text/javascript" src=<?php echo e(asset('revolution/js/extensions/revolution.extension.parallax.min.js')); ?>></script>
        <script type="text/javascript" src=<?php echo e(asset('revolution/js/extensions/revolution.extension.slideanims.min.js')); ?>></script>
        <script type="text/javascript" src=<?php echo e(asset('revolution/js/extensions/revolution.extension.video.min.js')); ?>><script>        <?php /**PATH /mnt/d/Projects/SinSis/resources/views/mainjs.blade.php ENDPATH**/ ?>