
<?php $__env->startSection('title', Auth::user()->name.' | Panel de Administación SinSis'); ?>
<?php $__env->startSection('body'); ?>
  <!-- start section -->
  <section class="wow fadeIn main-admin-container">
    <header class="main-admin-header position-fixed">
       <a href=<?php echo e(route('create-user')); ?> class="">+ Crear Nuevo Usuario</a> 
    </header>
    <?php if(Auth::user()->access_level == 3): ?>    
     <!-- start tab style 01 section -->
     <section class="wow fadeIn">
        <div class="container tab-style2">            
            <div class="row">
                <div class="col-12">
                    <!-- start tab navigation -->
                    <ul class="nav nav-tabs alt-font text-uppercase text-small text-center font-weight-600 justify-content-center">
                        <li class="nav-item"><a class="nav-link active" href="#tab_sec1" data-toggle="tab">Administradores</a></li>
                        <li class="nav-item"><a class="nav-link" href="#tab_sec2" data-toggle="tab">Clientes</a></li>                        
                    </ul>
                    <!-- end tab navigation -->
                </div>
            </div>                                
            <div class="tab-content">
                <!-- start tab content -->
                <div class="tab-pane med-text fade in active show" id="tab_sec1">
                    <div class="row align-items-center">
                        <div class="container">
                            <?php if(count($managers) > 0): ?>                
                        <table class="table table-striped">
                            <thead class="thead">
                                <th scope="col">
                                    Nombre
                                </th>
                                <th scope="col">
                                    Correo
                                </th>
                                <th scope="col" class="text-center">
                                    Proyectos
                                </th>
                                <th scope="col" class="text-center">
                                    Estado
                                </th>
                                <th class="text-center">
                                    Fecha de registro
                                </th>
                            </thead>
                            <?php $__currentLoopData = $managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>      
                            <!-- start features box item -->
                            <tr>
                                <td> <a href=<?php echo e(route('user-projects',$manager->id)); ?>><?php echo e($manager->name); ?></a></td>
                                <td><?php echo e($manager->email); ?></td>
                                <?php
                                    $manager_projects = DB::table('consultants_project')->where('user_id','=',$manager->id)->get();
                                ?>
                                <td class="text-center"><?php echo e(count($manager_projects)); ?></td>
                                <td class="text-center">
                                    <input type="checkbox" name="" id="" checked>
                                </td>
                                <td class="text-center"><?php echo e(date_format($manager->created_at,'d-m-Y')); ?></td>
                            </tr>
                            <!-- end features box item -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                        <?php else: ?>
                        <div class="text-center">
                            <h2><i class="far fa-frown"></i></h2>
                            <h2>No se han encontrado clientes.</h2>
                            <span>Puedes crear uno nuevo haciendo click en el boton de arriba.</span>
                        </div>
                        <?php endif; ?>
                    </div>
                    </div>
                </div>
                <!-- end tab content -->
                <!-- start tab content -->
                <div class="tab-pane fade in" id="tab_sec2">
                    <div class="row align-items-center">
                        <div class="container">
                            <?php if(count($clients) > 0): ?>                
                        <table class="table table-striped">
                            <thead class="thead">
                                <th scope="col">
                                    Nombre
                                </th>
                                <th scope="col">
                                    Correo
                                </th>
                                <th scope="col">
                                    Empresa
                                </th>
                                <th scope="col" class="text-center">
                                    Estado
                                </th>
                                <th class="text-center">
                                    Fecha de registro
                                </th>
                            </thead>
                            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>      
                            <!-- start features box item -->
                            <tr>
                                <td><?php echo e($client->name); ?></td>
                                <td><?php echo e($client->email); ?></td>
                                <td>
                                    <?php $__currentLoopData = $client->enterprises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enterprise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($enterprise->name); ?> <br>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                </td>
                                <td class="text-center">
                                    <input type="checkbox" name="" id="" checked>
                                </td>
                                <td class="text-center"><?php echo e(date_format($client->created_at,'d-m-Y')); ?></td>
                            </tr>
                            <!-- end features box item -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                        <?php else: ?>
                        <div class="text-center">
                            <h2><i class="far fa-frown"></i></h2>
                            <h2>No se han encontrado clientes.</h2>
                            <span>Puedes crear uno nuevo haciendo click en el boton de arriba.</span>
                        </div>
                        <?php endif; ?>
                    </div>                        
                    </div>
                </div>
                <!-- end tab content -->              
            </div>       
        </div>
    </section>
    <!-- end tab style 01 section -->
    <?php else: ?>
    <div class="container projects-container">
        <?php if(count($clients) > 0): ?>                
    <table class="table table-striped">
        <thead class="thead">
            <th scope="col">
                Nombre
            </th>
            <th scope="col">
                Correo
            </th>
            <th scope="col">
                Empresa
            </th>
            <th scope="col" class="text-center">
                Estado
            </th>
            <th class="text-center">
                Fecha de registro
            </th>
        </thead>
        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>      
        <!-- start features box item -->
        <tr>
            <td><?php echo e($client->name); ?></td>
            <td><?php echo e($client->email); ?></td>
            <td>
                <?php $__currentLoopData = $client->enterprises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enterprise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($enterprise->name); ?> <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </td>
            <td class="text-center">
                <input type="checkbox" name="" id="" checked>
            </td>
            <td class="text-center"><?php echo e(date_format($client->created_at,'d-m-Y')); ?></td>
        </tr>
        <!-- end features box item -->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php else: ?>
    <div class="text-center">
        <h2><i class="far fa-frown"></i></h2>
        <h2>No se han encontrado clientes.</h2>
        <span>Puedes crear uno nuevo haciendo click en el boton de arriba.</span>
    </div>
    <?php endif; ?>
</div>    
<?php endif; ?>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\SinSis_2\resources\views/admin/users/index.blade.php ENDPATH**/ ?>