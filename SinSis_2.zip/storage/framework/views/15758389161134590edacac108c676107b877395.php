<?php $__env->startSection('title', Auth::user()->name.' | Panel de Administación SinSis'); ?>
<?php $__env->startSection('body'); ?>
  <!-- start overline icon section -->  
  <section class="wow fadeIn main-admin-container">
    <header class="main-admin-header position-fixed">
        <a href=<?php echo e(route('create-diagnostics',$project->id)); ?> class="">+ Crear un nueva Diagnostico</a> Diagnosticos encontrados: <?php echo e(count($diagnostics)); ?>

     </header>    
        <div class="container projects-container">
                <?php if(count($diagnostics) > 0): ?>                
            <table class="table table-striped">
                <thead class="thead">
                    <th scope="col">
                        Descripcion
                    </th>
                    <th scope="col">
                        Archivos
                    </th>
                    <th scope="col">
                        Acciones
                    </th>
                    <th scope="col">
                        Fecha de creacion
                    </th>
                </thead>
                <?php $__currentLoopData = $diagnostics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diagnostic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>      
                <!-- start features box item -->
                <tr>
                    <td><?php echo e($diagnostic->description); ?></td>
                    <td><?php echo e($diagnostic->pdf_file); ?></td>
                    <td><a title="Descargar" href="" class="btn text-center btn-primary rounded"><i class="fas fa-download"></i></a>&nbsp;<a title="Eliminar" href="" class="btn text-center btn-danger rounded"><i class="fas fa-trash-alt"></i></a></td>
                    <td class="text-center"><?php echo e(date_format($diagnostic->created_at,'d-m-Y')); ?></td>
                </tr>
                <!-- end features box item -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <?php else: ?>
            <div class="text-center">
                <h2><i class="far fa-frown"></i></h2>
                <h2>No se han encontrado diagnosticos.</h2>
                <span>Puedes crear uno nuevo haciendo click en el boton de arriba.</span>
            </div>
            <?php endif; ?>
        </div>
    </section>
<!-- end overline icon section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\SinSis\resources\views/admin/diagnostics/index.blade.php ENDPATH**/ ?>