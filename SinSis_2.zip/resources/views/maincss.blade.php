        <link rel="stylesheet" href={{ asset('css/animate.css')}} />
        <!-- bootstrap -->
        <link rel="stylesheet" href={{ asset('css/bootstrap.min.css')}} />
        <!-- et line icon --> 
        <link rel="stylesheet" href={{ asset('css/et-line-icons.css')}} />
        <!-- font-awesome icon -->
        <link rel="stylesheet" href={{ asset('css/font-awesome.min.css')}} />
        <!-- themify icon -->
        <link rel="stylesheet" href={{ asset('css/themify-icons.css')}}>
        <!-- swiper carousel -->
        <link rel="stylesheet" href={{ asset('css/swiper.min.css')}}>
        <!-- justified gallery  -->
        <link rel="stylesheet" href={{ asset('css/justified-gallery.min.css')}}>
        <!-- magnific popup -->
        <link rel="stylesheet" href={{ asset('css/magnific-popup.css')}} />
        <!-- revolution slider -->
        {{-- <link rel="stylesheet" type="text/css" href={{ asset('revolution/css/settings.css')}} media="screen" />
        <link rel="stylesheet" type="text/css" href={{ asset('revolution/css/layers.css')}}>
        <link rel="stylesheet" type="text/css" href={{ asset('revolution/css/navigation.css')}}> --}}
        <!-- bootsnav -->
        <link rel="stylesheet" href={{ asset('css/bootsnav.css')}}>
        <!-- style -->
        <link rel="stylesheet" href={{ asset('css/style.css')}} />
        <!-- responsive css -->
        <link rel="stylesheet" href={{ asset('css/responsive.css')}} />
        <!--[if IE]>
            <script src="js/html5shiv.js"></script>
        <![endif]-->
        <!-- dropzone css buto -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.5.1/dropzone.css" />
        <link rel="stylesheet" href="{{ asset('css/styles/main.css') }}">   
        <link rel="stylesheet" href="{{ asset('css/musustyles/mstyles.css') }}">
        <link rel="stylesheet" href="{{ asset('css/styles/marcel.css') }}">        
