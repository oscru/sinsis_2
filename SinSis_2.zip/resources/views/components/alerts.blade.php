<div class="alert alert-success position-fixed  d-none" role="alert" style="width: 60%;z-index:10" id="user-created-alert">
    Se ha creado un nuevo usuario.
</div>

<div class="alert alert-success position-fixed  d-none" role="alert" style="width: 60%;z-index:10" id="enterprise-created-alert">
    Se ha creado una nueva empresa.
</div>

<div class="alert alert-success position-fixed  d-none m-0" role="alert" style="width: 60%;z-index:10" id="added-user-project">
    Se ha asignado al usuario correctamente.
</div>